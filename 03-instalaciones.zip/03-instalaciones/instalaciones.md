# Pasos para instalar
1. seguir estos pasos ......
npm install

2. Ejecutar commando 
npm start

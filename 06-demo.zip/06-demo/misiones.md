# Misiones

1. Acabar con el plan de Lex Luthor
2. Crear la liga de la justicia
3. Buscar nuevos miembros que sean super heroes
4. buscar comida para ellos.

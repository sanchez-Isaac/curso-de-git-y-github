# Misiones

* Investigar los planes del Dr. Doom
* Capturar a Red Skull
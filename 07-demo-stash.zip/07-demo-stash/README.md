# Objetivos Y Notas

Este es un repositorio de la liga de la justicia

cmd/ctrl+shift+p = para insertar un parrafo lorem de daniel imms

Fugiat qui fugiat minim exercitation ipsum cupidatat tempor commodo amet tempor eiusmod officia cillum. Ut do aliquip nulla ipsum ad et in. Ipsum ipsum reprehenderit incididunt ea ex occaecat aliquip fugiat sit et et pariatur ad. Officia ea aliqua dolor dolor minim fugiat do Lorem deserunt occaecat. Do enim ipsum officia incididunt cupidatat fugiat.
# Misiones
* Crear la liga de la justicia
* Investigar los trabajo del joker 
* Tratar de investigar que trama el Flash Reverso
